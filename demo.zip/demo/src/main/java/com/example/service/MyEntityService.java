package com.example.service;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotBlank;

import com.example.model.MyEntity;
import com.example.repository.MyEntityRepositoryImpl;

import io.micronaut.runtime.http.scope.RequestScope;
import jakarta.inject.Inject;

@RequestScope
public class MyEntityService {

	@Inject
	private MyEntityRepositoryImpl repo;
	 
	public Optional<MyEntity> findById(int id) {
		return this.repo.findById(id);
	}

 
	public MyEntity save(@NotBlank MyEntity myentity) {
		return this.repo.save(myentity);
	}

 
	public void deleteById(int id) {
		this.repo.deleteById(id);

	}
 
	public List<MyEntity> findAll() {
	return	this.repo.findAll();
	}
	
	
}

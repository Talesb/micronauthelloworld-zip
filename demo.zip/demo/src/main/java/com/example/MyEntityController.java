package com.example;

import java.util.List;

import javax.validation.Valid;

import com.example.model.MyEntity;
import com.example.service.MyEntityService;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Delete;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;
import jakarta.inject.Inject;

@ExecuteOn(TaskExecutors.IO)
@Controller("/myentity")
public class MyEntityController {

	@Inject
	private MyEntityService myEntityService;

	@Get(uri = "/", produces = "application/json")
	public List<MyEntity> findAll() {
		return myEntityService.findAll();
	}

	@Get("/{id}")
	MyEntity show(int id) {
		return myEntityService.findById(id).orElse(null);
	}

	@Post
	HttpResponse<MyEntity> save(@Body @Valid MyEntity entity) {
		MyEntity me = myEntityService.save(entity);
		return HttpResponse.created(me);

	}

	@Delete("/{id}")
	HttpResponse<?> delete(int id) {
		myEntityService.deleteById(id);
		return HttpResponse.noContent();
	}

}
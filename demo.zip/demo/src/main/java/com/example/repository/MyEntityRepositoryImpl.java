package com.example.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import javax.validation.constraints.NotBlank;

import com.example.model.MyEntity;

import io.micronaut.runtime.ApplicationConfiguration;
import io.micronaut.transaction.annotation.ReadOnly;
import jakarta.inject.Singleton;

@Singleton
public class MyEntityRepositoryImpl implements MyEntityRepository {

	private final EntityManager entityManager;
	private final ApplicationConfiguration applicationConfiguration;

	public MyEntityRepositoryImpl(EntityManager entityManager, ApplicationConfiguration applicationConfiguration) {
		this.entityManager = entityManager;
		this.applicationConfiguration = applicationConfiguration;
	}

	@ReadOnly
	@Override
	public Optional<MyEntity> findById(int id) {
		return Optional.ofNullable(entityManager.find(MyEntity.class, id));
	}

	@Transactional
	@Override
	public MyEntity save(@NotBlank MyEntity myentity) {
		entityManager.persist(myentity);
		return myentity;
	}

	@Transactional
	@Override
	public void deleteById(int id) {
		findById(id).ifPresent((me) -> {
			entityManager.remove(me);
		});

	}
	
	@ReadOnly
	@SuppressWarnings("unchecked")
	@Override
	public List<MyEntity> findAll() {
		return entityManager.createQuery("Select e from MyEntity as e").getResultList();
	}

	@Override
	public int update(int id, @NotBlank String name) {
		// TODO Auto-generated method stub
		return 0;
	}

}

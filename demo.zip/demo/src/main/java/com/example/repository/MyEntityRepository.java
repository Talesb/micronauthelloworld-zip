package com.example.repository;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotBlank;

import com.example.model.MyEntity;

 
public interface MyEntityRepository {

	
	Optional<MyEntity> findById(int id);

	MyEntity save(@NotBlank MyEntity me);

    void deleteById(int id);

    List<MyEntity> findAll();

    int update(int id, @NotBlank String name);
	
}
